#ifndef INIT_MCU_H
#define INIT_MCU_H

#ifdef __cplusplus
extern "C" {
#endif

void initMcu(void);

#ifdef __cplusplus
}
#endif

#endif // INIT_MCU_H
