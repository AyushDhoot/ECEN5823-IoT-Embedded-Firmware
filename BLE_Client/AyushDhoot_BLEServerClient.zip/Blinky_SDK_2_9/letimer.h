/*
 * letimer.h
 *
 *  Created on: 15-Sep-2018
 *      Author: Ayush
 */


#include "em_letimer.h"

void LETIMER0_IRQHandler(void);
void LETimer0Setup();
//void LETIMER_Enable();
